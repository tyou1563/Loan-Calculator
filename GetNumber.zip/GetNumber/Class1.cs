﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        int lowerLimit = 0;
        int upperLimit = 10;

        int number = GetNumber(lowerLimit, upperLimit);
        Console.WriteLine("You entered " + number);
    }

    public static int GetNumber(int lowerLimit, int upperLimit)
    {
        int number;

        do
        {
            Console.WriteLine($"Enter a number between {lowerLimit} and {upperLimit}: ");
            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }
        } while (number < lowerLimit || number > upperLimit);

        return number;
    }
}
